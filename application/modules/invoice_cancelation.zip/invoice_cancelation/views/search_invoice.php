<?php
foreach($invoice->result() as $row)
{
	$book_num=$row->BOOK_NUMBER;
	$invo_date=$row->INVOICE_DATE;
	if($invo_date != '')
	{
		$invo_date=strtotime($invo_date);
		$invo_date=date('d-m-Y',$invo_date);
	}
	$cust_name=$row->c_name;
	$cust_id=$row->c_id;
	$description=$row->DESCRIPTION;
}
?>
<div id="output">
<div class="row">
            <div class="col-sm-12">
            	<div class="row">
                <div class="col-md-4">
                  <div class="form-group">
                    <label class="control-label"> Book Number </label>
                    <div class="input-group">
                      <input type="text" name="temp_invo_num" id="temp_invo_num" Class="form-control" value="<?php echo $book_num; ?>"/>
                      <span class="input-group-btn"> <a data-toggle="modal" class="demo btn btn-dark-beige" onclick="displaydata()"> GO </a> </span></div>
                  </div>
                </div>
                <div class="col-md-8">
                  <div class="form-group">
                    <label class="control-label"> Invoice Date <span class="symbol required"> </span> </label>
                    <span class="input-icon input-icon-right">
                    <input type="text" data-date-format="dd-mm-yyyy" data-date-viewmode="years" class="form-control date-picker" id="txt_invoice_date" name="txt_invoice_date" value="<?php echo $invo_date; ?>" readonly="readonly"/>
                    <i class="icon-calendar"></i> </span> </div>
                </div>
                </div>
                
                <div class="row">
                <div class="col-md-12">
                  <div class="form-group" id="h1">
                    <label class="control-label">Customer Name <span class="symbol required"> </span></label>
                    <select class="form-control" id="txt_cust_name" name="txt_cust_name" readonly="readonly">
                    
                      <option value="<?php echo $cust_id; ?>"><?php echo $cust_name; ?></option>
                      
                    </select>
                  </div>
                </div>
                
                 <div class="col-sm-12">
                 	<div class="form-group">
                    <label class="control-label">Description <span class="symbol required"> </span></label>
                 	<textarea class="form-control" name="txt_des" id="txt_des" readonly="readonly"><?php echo $description; ?></textarea>
                    </div>
                 </div>
              </div>
            </div>
         </div>
		 </div>
		 
		 
		 
		 
		 
		 $book_num=$this->input->post('invoice_no');
		$data['invoice']=$this->db->query("select tbl_invoice.*,tbl_account.ACC_ID as c_id,tbl_account.ACC_NAME as c_name from tbl_invoice join tbl_account on tbl_invoice.CUSTOMER_ID=tbl_account.ACC_ID where tbl_invoice.BOOK_NUMBER=$book_num and tbl_invoice.BOOK_NAME='INVO'");
		if($data['invoice']->num_rows() <1)
		{
			echo "no result";
		}
		else
		{
			
			$this->load->view('search_invoice',$data);
			
		}