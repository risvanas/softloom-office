<?php
class Menu_management extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'template'));
		$this->template->set_template('admin_template');
		$this->load->helper('date');
		$this->load->library('form_validation');
		$this->load->model('menu_management_model');
		$this->load->library('encrypt');
		
	}
	
	
	function index()
	{
		$this->form_validation->set_rules('txt_sub_menu','required','required');
		$data['pmenu']=$this->menu_management_model->select_pmenu('tbl_menu');
		if($this->form_validation->run()!=TRUE)
		{
			$data['msg']="";
			$data['errmsg']="";
			$layout=array('page'=>'form_addmenu','title'=>'Add menu','data'=>$data);
			render_template($layout);
			//$this->load->view('form_invoice',$data);
		}
		else
		{
			$p_menu=$this->input->post('drp_prt_menu');
			$s_menu=$this->input->post('txt_sub_menu');
			$url=$this->input->post('txt_url');
			$icon=$this->input->post('txt_icon');
			$source=$this->input->post('txt_source');
			$data=array('P_MENU_ID'=>$p_menu,
			            'SUB_MENU'=>$s_menu,
						'URL'=>$url,
						'ICON'=>$icon,
						'SOURCE'=>$source,
						'DEL_FLAG'=>1);
				$this->menu_management_model->insert_data('tbl_menu',$data);
				$data['pmenu']=$this->menu_management_model->select_pmenu('tbl_menu');
				$data['msg']="New Menu Added Successfully";
			$data['errmsg']="";
			$layout=array('page'=>'form_addmenu','title'=>'Add menu','data'=>$data);
			render_template($layout);
		}
	}
	function menulist()
	{
		$data['list']=$this->menu_management_model->select_all();
		$data['msg']="";
			$data['errmsg']="";
			$layout=array('page'=>'form_menulist','title'=>'Add menu','data'=>$data);
			render_template($layout);
	}
   function menuedit()
   {
	   $id=$this->uri->segment(3);
	   $data['pmenu']=$this->menu_management_model->select_pmenu('tbl_menu');
	   $data['menu']=$this->menu_management_model->select_individual('tbl_menu',$id);
	   $data['msg']="";
			$data['errmsg']="";
			$layout=array('page'=>'form_menuedit','title'=>'Add menu','data'=>$data);
			render_template($layout);
   }
   function menu_update()
   {
	   $this->form_validation->set_rules('txt_sub_menu','required','required');
		if($this->form_validation->run()!=TRUE)
		{
			$data['msg']="";
			$data['errmsg']="Please Enter Data";
			$layout=array('page'=>'form_addmenu','title'=>'Add menu','data'=>$data);
			render_template($layout);
			//$this->load->view('form_invoice',$data);
		}
		else
		{
			$p_menu=$this->input->post('drp_prt_menu');
			$s_menu=$this->input->post('txt_sub_menu');
			$url=$this->input->post('txt_url');
			$icon=$this->input->post('txt_icon');
			$source=$this->input->post('txt_source');
			$data=array('P_MENU_ID'=>$p_menu,
			            'SUB_MENU'=>$s_menu,
						'URL'=>$url,
						'ICON'=>$icon,
						'SOURCE'=>$source);
			$id=$this->input->post('m_id');
	   $this->menu_management_model->update('tbl_menu',$id,$data);
	   $data['list']=$this->menu_management_model->select_all();
		redirect('menu_management/menulist');
		}
	   
   }
   function menu_delete()
   {
	   $id=$this->uri->segment(3);
	   $data=array('DEL_FLAG'=>0);
	   $this->menu_management_model->update('tbl_menu',$id,$data);
	   redirect('menu_management/menulist');
   }
		
}

?>