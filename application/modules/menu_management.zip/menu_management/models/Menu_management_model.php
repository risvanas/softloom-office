<?php
class Menu_management_model extends CI_Model
{
	
	
	function insert_data($table,$data)
	{
		$this->db->insert($table,$data);
	}
	
	function select_all()
	{
		$this->db->select('tbl_menu.P_MENU_ID as P_MENU_ID,tbl_menu.SUB_MENU as SUB_MENU,tbl_menu.URL as URL,tbl_menu.ICON as ICON,tbl_menu.SOURCE as SOURCE,tbl_menu.ICON as ICON,tbl_menu.MENU_ID as MENU_ID,menu.SUB_MENU as pmenu');
		$this->db->from('tbl_menu');
		$this->db->join('tbl_menu as menu','tbl_menu.P_MENU_ID = menu.MENU_ID','left');
		$this->db->where('tbl_menu.DEL_FLAG',1);
		$query=$this->db->get();
		return $query;
	}	
	function select_individual($table,$id)
	{
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where('MENU_ID',$id);
		$this->db->where('DEL_FLAG',1);
		$query=$this->db->get();
		return $query;
	}
	function update($table,$id,$data)
	{
		$this->db->where('MENU_ID',$id);
		$this->db->where('DEL_FLAG',1);
		$this->db->update($table,$data);
	}
	function select_pmenu($table)
	{
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where('P_MENU_ID','');
		$this->db->where('DEL_FLAG',1);
		$query=$this->db->get();
		return $query;
	}
}

?>