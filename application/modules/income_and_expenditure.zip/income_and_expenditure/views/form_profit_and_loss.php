
<table class="table table-striped table-bordered table-hover table-full-width" id="sample_1">
<thead>
    <tr>
			<th>sl no</th>
			<th>Account</th>
    		<th>Income</th>
            <th>Expenses</th>
            
    	
    </tr>
    </thead>
    <tbody>
<?php
$count=1;
$income_sum=0;
$expence_sum=0;
foreach($data_pass->result() as $row)
{
	
	?>
<tr>
<td><?php echo $count; ?></td>

<?php
if($row->id==3)
	{
		$val="INCOME";
		$income_sum+=$row->income;
		?>
		<td><?php echo $row->a_name.' [INCOME]'; ?></td>
		<td><?php echo abs($row->income); ?></td>
<td></td>
<?php
	}
	elseif($row->id==4)
	{
		$val="EXPENSES";
		$expence_sum+=$row->income;
		?>
		<td><?php echo $row->a_name.' [EXPENSES]'; ?></td>
		<td></td>
<td><?php echo abs($row->income); ?></td>
<?php
	}
?>

</tr>
<?php
$count++;
}
?>
<tr><td></td><td><b>Total</b></td><td><b><?php
echo abs($income_sum); ?></b></td><td><b><?php
echo abs($expence_sum); ?></b></td></tr>
</tbody>
</table>