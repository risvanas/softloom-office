<?php
class Income_and_expenditure extends MX_Controller
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'template'));
		$this->load->helper('date');
		$this->template->set_template('admin_template');
	}
	function index()
	{
		$layout = array('page' => 'form_income_and_expenditure','title'=>'Income and Expenditure');	
		render_template($layout);
	}
	function calculation()
	{
		$from_date=$this->input->post("from_date");
		$from_date=strtotime($from_date);
		echo $from_date=date('Y-m-d',$from_date)." to ";
		
		$to_date=$this->input->post("to_date");
		$to_date=strtotime($to_date);
		echo $to_date=date('Y-m-d',$to_date);
		
		$data['data_pass']=$this->db->query("SELECT IFNULL( SUM( DEBIT ) , 0 ) - IFNULL( SUM( CREDIT ) , 0 ) AS income,tbl_account.PARENT_ACC_ID as id,tbl_account.ACC_NAME as a_name FROM `tbl_transaction` join tbl_account on tbl_transaction.ACC_ID=tbl_account.ACC_ID where tbl_account.PARENT_ACC_ID in(3,4) and tbl_transaction.DEL_FLAG=1 and tbl_transaction.DATE_OF_TRANSACTION>='$from_date' and tbl_transaction.DATE_OF_TRANSACTION<='$to_date' group by tbl_account.ACC_ID");
			   $this->load->view('form_profit_and_loss',$data);

	}
	
}
?>