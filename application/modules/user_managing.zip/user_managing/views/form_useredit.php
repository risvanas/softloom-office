<div class="row" style="padding-top:20px;">
  <div class="col-md-12"> 
    <!-- start: DYNAMIC TABLE PANEL -->
    <div class="panel panel-default">
      <div class="panel-heading"> <i class="icon-external-link-sign"></i>&nbsp Edit User
        <div class="panel-tools"> <a class="btn btn-xs btn-link panel-collapse collapses" href="#"></a><a class="btn btn-xs btn-link panel-config"
                            href="#panel-config" data-toggle="modal"><i class="icon-wrench"></i></a><a class="btn btn-xs btn-link panel-refresh"
                                href="#"><i class="icon-refresh"></i></a><a class="btn btn-xs btn-link panel-expand"
                                    href="#"><i class="icon-resize-full"></i></a><a class="btn btn-xs btn-link panel-close"
                                        href="#"><i class="icon-remove"></i></a> </div>
      </div>
      <form  method="post" name="form" action="<?php echo site_url('user_managing/update');?>" id="form">
        <div class="panel-body">
        <div class="successHandler alert alert-success <?php if($msg == ""){?> no-display <?php }?>"> <button class="close" data-dismiss="alert">
											×
										</button>
										<i class="icon-ok-sign"></i> <?php echo $msg; ?> </div>
		<div class="successHandler alert alert-danger <?php if( $errmsg=="" ){ ?> no-display <?php }?>"> <i class="icon-remove"></i> <?php echo $errmsg;?> </div>
         <h2><i class="icon-edit-sign teal"></i> Edit User</h2>
          <div>
            <hr />
          </div>
          <?php
		  foreach($edit->result() as $row)
		  {
			  $username=$row->USER_NAME;
			  $first=$row->FIRST_NAME;
			  $last=$row->LAST_NAME;
			  $password=$row->PASSWORD;
			  $user_id=$row->USER_ID;
		  }
		  ?>
            <div class="row">
              <div class="col-md-12">
			  <div class="row">
			  <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label"> User Name </label>
                     <input type="text" class="form-control" id="txt_username" name="txt_username" value="<?php echo $username; ?>"/>
					 <input type="hidden" id="txt_id" name="txt_id" value="<?php echo $user_id; ?>"/>
                    </div>
                  </div>
				  
			  </div>
			  
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label"> First Name <span class="symbol required"> </span> </label>
                      <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $first; ?>"/>
                      
                    </div>
                  </div>
				  </div>
				   <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label"> Last Name <span class="symbol required"></span> </label>
                      <input type="text" class="form-control" id="last_name" name="last_name"  value="<?php echo $last; ?>"/>
                      
                    </div>
                  </div>
              	</div>
               
               
                <div class="row"> 
                	<div class="col-md-3">
                    <div class="form-group">
                      <label class="control-label"> Password <span class="symbol required"></span> </label>
                      <input type="password" class="form-control" id="txt_password" name="txt_password"  value="<?php echo $password; ?>"/>
                      
                    </div>
                  </div>
                </div>
				
                
               
                <div class="row">
                  <div class="col-md-12">
                    <div> <span class="symbol required"></span>Required Fields
                      <hr />
                    </div>
                  </div>
                </div>
                
                <div class="row">
            <div class="col-md-10">
              <p> </p>
            </div>
            <div class="col-md-2">
              <button class="btn btn-primary btn-block" type="submit"> Update <i class="icon-circle-arrow-right"></i> </button>
            </div>
          </div>
                
              </div>
            </div>
          
          <!-- end: DYNAMIC TABLE PANEL --> 
        </div>
      </form>
    </div>
  </div>
  <!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY --> 
</div>


<script src="<?php echo base_url(); ?>assets/plugins/jquery-validation/dist/jquery.validate.min.js"></script> 
        <script src="<?php echo base_url(); ?>assets/js/form-validation/account_year_registration.js"></script> 
        
                
       <script>
	
   jQuery(document).ready(function() {
	Main.init();
	FormValidator.init();
	FormElements.init();
	
});
		

		</script> 