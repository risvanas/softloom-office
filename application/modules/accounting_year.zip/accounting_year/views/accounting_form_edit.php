<div class="row" style="padding-top:20px;">
  <div class="col-md-12"> 
    <!-- start: DYNAMIC TABLE PANEL -->
    <div class="panel panel-default">
      <div class="panel-heading"> <i class="icon-external-link-sign"></i>&nbsp; Accounting Year
        <div class="panel-tools"> <a class="btn btn-xs btn-link panel-collapse collapses" href="#"></a><a class="btn btn-xs btn-link panel-config"
                            href="#panel-config" data-toggle="modal"><i class="icon-wrench"></i></a><a class="btn btn-xs btn-link panel-refresh"
                                href="#"><i class="icon-refresh"></i></a><a class="btn btn-xs btn-link panel-expand"
                                    href="#"><i class="icon-resize-full"></i></a><a class="btn btn-xs btn-link panel-close"
                                        href="#"><i class="icon-remove"></i></a> </div>
      </div>
      <form  role="form" id="form" method="post" action="<?php  echo site_url('accounting_year/accounting_year_update');?>">
        <div class="panel-body" >
          <div class="successHandler alert alert-success <?php if($msg == ""){?> no-display <?php }?>">
            <button class="close" data-dismiss="alert"> × </button>
            <i class="icon-ok-sign"></i> <?php echo $msg; ?> </div>
          <h2><i class="icon-group teal"></i> Edit Accounting Year</h2>
          <div>
            <hr />
          </div>
		  <?php
		  foreach($edit_list->result() as $row)
		  {
			$from=$row->FROM_DATE;
			if($from != '')
			  {
				$from=strtotime($from);
				$from=date('d-m-Y',$from);
			  }
		  $to=$row->TO_DATE;
			if($to != '')
			  {
				$to=strtotime($to);
				$to=date('d-m-Y',$to);
			  }
		  ?>
		  <div class="row">
              <div class="col-md-6">
			   <div class="row">
                  <div class="col-md-12">
                    <div class="form-group">
                      <label class="control-label"> Account Year Code <span class="symbol required"> </span> </label>
                      <input type="text" class="form-control" id="year_code" name="year_code" value="<?php echo $row->YEAR_CODE; ?>" />
					  <input type="hidden" name="aid" id="aid" value="<?php echo $this->uri->segment(3); ?>">
                    </div>
                  </div>
                </div>
				<div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label">From Date <span class="symbol required"> </span></label>
                      <span class="input-icon input-icon-right">
                      <input type="text" data-date-format="dd-mm-yyyy" data-date-viewmode="years" class="form-control date-picker" name="txt_from" id="txt_from"  value="<?php echo $from; ?>" />
                      <i class="icon-calendar"></i> </span> </div>
                  </div>
				  <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label">To Date <span class="symbol required"> </span></label>
                      <span class="input-icon input-icon-right">
                      <input type="text" data-date-format="dd-mm-yyyy" data-date-viewmode="years" class="form-control date-picker" name="txt_to" id="txt_to"  value="<?php echo $to ?>" />
                      <i class="icon-calendar"></i> </span> </div>
                  </div>
				  </div>
				   <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label class="control-label"> Status </label>
                      <span class="symbol required"> </span>
                      <select class="form-control" id="drp_status" name="drp_status">
                        <option value="">Select</option>
                        <option value="active" <?php if($row->STATUS == 'active'){ ?> selected="selected" <?php } ?>>Active</option>
                        <option value="inactive"<?php if($row->STATUS == 'inactive'){ ?> selected="selected" <?php } ?>>Inactive</option>
                      </select>
                    </div>
                  </div>
				  </div>
				</div>
				</div>
				<?php
		  }
		  ?>
		 <div class="row">
              <div class="col-md-12">
		<div class="row">
            <div class="col-md-12">
              <div> <span class="symbol required"></span>Required Fields
                <hr>
              </div>
            </div>
          </div>
		  <div class="row">
            <div class="col-md-10">
              <p> </p>
            </div>
            <div class="col-md-2">
              <button class="btn btn-dark-beige btn-block" type="submit" id="sub_reg" name="sub_reg"> Update <i class="icon-circle-arrow-right"></i> </button>
            </div>
          </div>
		  </div></div>
		  </div>
		  </form>
		  
		  </div></div></div>
<script src="<?php echo base_url(); ?>assets/plugins/jquery-validation/dist/jquery.validate.min.js"></script> 
<script src="<?php echo base_url(); ?>assets/js/form-validation/accounting_form.js"></script> 
<script>
	
		jQuery(document).ready(function() {
		Main.init();
		FormValidator.init();
		FormElements.init();
		
		
	    });

		</script>