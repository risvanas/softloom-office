<table  width="200" class="table table-full-width" id="sample_1">
        <thead>
            <th>No</th>
			<th>Menu Name</th>
			<th>Add</th>
			<th>Edit</th>
			<th>Delete</th>
			<th>View</th>
		</thead>
		<tbody>
		<?php
		$count=1;
		foreach($menu->result() as $row1)
		{
			?>
			<tr bgcolor="#BBD749">
			<td><?php echo $count; ?></td>
		<td><?php echo $row1->SUB_MENU; ?> 
		<input type="hidden" id="txt_menu[<?php echo $count; ?>]" name="txt_menu[<?php echo $count; ?>]" value="<?php echo $id=$row1->MENU_ID; ?>"></td>
		<td>
		<?php
		$sql="select * from tbl_permition where USER_ID=$user and DEL_FLAG=1 and MENU_ID=$id";
		$query=$this->db->query($sql);
		$val=$query->row_array();
		$add_val=$val['ADD'];
		 $edit_val=$val['EDIT'];
		 $delete_val=$val['DELETE'];
		 $view_val=$val['VIEW'];
		?>
		<input type="checkbox" value="1" id='add[<?php echo $count; ?>]' name='add[<?php echo $count; ?>]' <?php if($add_val==1) { ?> checked="checked" <?php } ?>/></td>
		<td><input type="checkbox" value="1" id='edit[<?php echo $count; ?>]' name='edit[<?php echo $count; ?>]' <?php if($edit_val==1) { ?> checked="checked" <?php } ?>/></td>
		<td><input type="checkbox" value="1" id='delete[<?php echo $count; ?>]' name='delete[<?php echo $count; ?>]' <?php if($delete_val==1) { ?> checked="checked" <?php } ?>/></td>
		<td><input type="checkbox" value="1" id='view[<?php echo $count; ?>]' name='view[<?php echo $count; ?>]' <?php if($view_val==1) { ?> checked="checked" <?php } ?>/></td>
		</tr>
		<?php
		$sql="select * from tbl_menu where P_MENU_ID=$id";
		$query=$this->db->query($sql);
		foreach($query->result() as $val)
		{
			$count++;
			?>
			<tr>
			<td><?php echo $count; ?></td>
		<td><?php echo $val->SUB_MENU; ?> 
		<input type="hidden" id="txt_menu[<?php echo $count; ?>]" name="txt_menu[<?php echo $count; ?>]" value="<?php echo $s_id=$val->MENU_ID; ?>"></td>
		<td>
		<?php
		$sql="select * from tbl_permition where USER_ID=$user and DEL_FLAG=1 and MENU_ID=$s_id";
		$query=$this->db->query($sql);
		$val=$query->row_array();
	 $add_val=$val['ADD'];
		 $edit_val=$val['EDIT'];
		 $delete_val=$val['DELETE'];
		 $view_val=$val['VIEW'];
		?>
		<input type="checkbox" value="1" id='add[<?php echo $count; ?>]' name='add[<?php echo $count; ?>]' <?php if($add_val==1) { ?> checked="checked" <?php } ?>/></td>
		<td><input type="checkbox" value="1" id='edit[<?php echo $count; ?>]' name='edit[<?php echo $count; ?>]' <?php if($edit_val==1) { ?> checked="checked" <?php } ?>/></td>
		<td><input type="checkbox" value="1" id='delete[<?php echo $count; ?>]' name='delete[<?php echo $count; ?>]' <?php if($delete_val==1) { ?> checked="checked" <?php } ?>/></td>
		<td><input type="checkbox" value="1" id='view[<?php echo $count; ?>]' name='view[<?php echo $count; ?>]' <?php if($view_val==1) { ?> checked="checked" <?php } ?>/></td>
		</tr>
			<?php
		}
		$count++;
		}
		?>
		</tbody>
		</table>